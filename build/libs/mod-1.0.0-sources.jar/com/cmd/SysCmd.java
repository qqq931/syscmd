package com.cmd;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_7157;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SysCmd implements ModInitializer {
    public static final String MOD_ID = "mc2cmd";
    public static final String MOD_VERSION = "1.10.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("MC2CMD v{} 已启动 - CMD + PowerShell 双支持", MOD_VERSION);
        CommandRegistrationCallback.EVENT.register(this::registerAllCommands);
    }

    private void registerAllCommands(
            CommandDispatcher<class_2168> dispatcher,
            class_7157 registryAccess,
            class_2170.class_5364 environment
    ) {

        // ======================
        // 原版 CMD 指令（不动）
        // ======================
        dispatcher.register(
            class_2170.method_9247("cmd")
                .requires(source -> source.method_9259(4))
                .then(class_2170.method_9244("command", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        String cmd = StringArgumentType.getString(ctx, "command");
                        try {
                            String safeCmd = cmd.replace("\"", "\\\"").replace("&", "^&");
                            Runtime.getRuntime().exec("cmd.exe /c " + safeCmd);
                            source.method_9226(() -> class_2561.method_43469("mc2cmd.cmd.success", cmd), false);
                        } catch (Exception e) {
                            source.method_9226(() -> class_2561.method_43469("mc2cmd.cmd.error", e.getMessage()), false);
                            e.printStackTrace();
                        }
                        return 1;
                    })
                )
        );

        dispatcher.register(
            class_2170.method_9247("cmdadmin")
                .requires(source -> source.method_9259(4))
                .then(class_2170.method_9244("command", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        String cmd = StringArgumentType.getString(ctx, "command");
                        try {
                            String safeCmd = cmd.replace("\"", "\\\"").replace("&", "^&");
                            Runtime.getRuntime().exec(
                                "powershell -Command Start-Process cmd.exe -ArgumentList '/c " + safeCmd + "' -Verb RunAs"
                            );
                            source.method_9226(() -> class_2561.method_43469("mc2cmd.cmdadmin.success", cmd), false);
                        } catch (Exception e) {
                            source.method_9226(() -> class_2561.method_43469("mc2cmd.cmdadmin.error", e.getMessage()), false);
                            e.printStackTrace();
                        }
                        return 1;
                    })
                )
        );

        // ======================
        // 新增：PowerShell 指令
        // ======================
        dispatcher.register(
            class_2170.method_9247("ps")
                .requires(source -> source.method_9259(4))
                .then(class_2170.method_9244("command", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        String cmd = StringArgumentType.getString(ctx, "command");
                        try {
                            String safeCmd = cmd.replace("\"", "\\\"");
                            // 直接用 PowerShell 执行
                            Runtime.getRuntime().exec("powershell.exe -Command " + safeCmd);
                            // 直接复用你现有的多语言键，不用加新翻译！
                            source.method_9226(() -> class_2561.method_43469("mc2cmd.cmd.success", cmd), false);
                        } catch (Exception e) {
                            source.method_9226(() -> class_2561.method_43469("mc2cmd.cmd.error", e.getMessage()), false);
                            e.printStackTrace();
                        }
                        return 1;
                    })
                )
        );

        dispatcher.register(
            class_2170.method_9247("psadmin")
                .requires(source -> source.method_9259(4))
                .then(class_2170.method_9244("command", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        String cmd = StringArgumentType.getString(ctx, "command");
                        try {
                            String safeCmd = cmd.replace("\"", "\\\"");
                            // 管理员 PowerShell
                            Runtime.getRuntime().exec(
                                "powershell -Command Start-Process powershell.exe -ArgumentList '-Command \"" + safeCmd + "\"' -Verb RunAs"
                            );
                            // 复用现有语言
                            source.method_9226(() -> class_2561.method_43469("mc2cmd.cmdadmin.success", cmd), false);
                        } catch (Exception e) {
                            source.method_9226(() -> class_2561.method_43469("mc2cmd.cmdadmin.error", e.getMessage()), false);
                            e.printStackTrace();
                        }
                        return 1;
                    })
                )
        );
    }
}
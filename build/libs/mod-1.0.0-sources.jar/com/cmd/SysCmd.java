// 包名严格匹配路径：com.cmd
package com.cmd;

// 1.20.1版本正确的导入（无笔误、全适配）
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_7157;

// 类名 = 文件名：SysCmd（公共类必须和文件名一致）
public class SysCmd implements ModInitializer {
    // 模组ID（和fabric.mod.json里的id一致）
    public static final String MOD_ID = "mc2cmd";

    @Override
    public void onInitialize() {
        // 注册/cmd命令（Fabric API v2，适配1.20.1）
        CommandRegistrationCallback.EVENT.register(this::registerCmdCommand);
    }

    // 命令注册方法（参数无笔误、类型全正确）
    private void registerCmdCommand(
            CommandDispatcher<class_2168> dispatcher,
            class_7157 registryAccess,
            class_2170.class_5364 environment
    ) {
        // 注册/cmd命令，仅管理员可执行
        dispatcher.register(
                class_2170.method_9247("cmd")
                        .requires(source -> source.method_9259(4)) // 管理员权限
                        .then(class_2170.method_9244("command", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    class_2168 source = ctx.getSource();
                                    String cmd = StringArgumentType.getString(ctx, "command");

                                    try {
                                        // 转义特殊字符，避免执行失败
                                        String safeCmd = cmd.replace("\"", "\\\"").replace("&", "^&");
                                        // 以管理员执行CMD命令
                                        Runtime.getRuntime().exec(
                                                "powershell -Command Start-Process cmd.exe -ArgumentList '/c " + safeCmd + "' -Verb RunAs"
                                        );
                                        source.method_9226(() -> class_2561.method_43470("§a✅ 已请求管理员执行: " + cmd), false);
                                    } catch (Exception e) {
                                        source.method_9226(() -> class_2561.method_43470("§c❌ 执行失败: " + e.getMessage()), false);
                                        e.printStackTrace(); // 控制台打印异常，方便调试
                                    }
                                    return 1;
                                })
                        )
        );
    }
}